<html>
<head>
<h1>My name is Asif Nawaz</h1>
</head>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/about.blade.php ENDPATH**/ ?>